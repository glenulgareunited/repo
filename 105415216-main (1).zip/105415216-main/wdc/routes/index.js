var express = require('express');
var router = express.Router();


let post_list = [
]



router.post('/newpost', function(req, res, next) {
});

router.post('/newpost', function(req, res, next) {
});

router.post('/newpost', function(req, res, next) {
});

router.post('/newpost', function(req, res, next) {
});

 router.post('/newpost', function(req, res, next) {
 });

module.exports = router;
