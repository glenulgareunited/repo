
let post_list = [];

function new_post() {

    let title = document.getElementById('title').value;
    let subtitle = document.getElementById('subtitle').value;
    let desc = document.getElementById('post-content').value;
    let tags = document.getElementById('post-tags').value.split(" ");

    let new_p = {title: title, desc: desc, tags: tags};

    let xhttp = new XMLHttpRequest();


    xhttp.open("POST", "/newpost");
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(new_p));

}
